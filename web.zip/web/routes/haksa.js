var express = require('express');
var router = express.Router();
const { getConnection } = require('../connect');
const oracledb = require('oracledb');

/* 교수페이지이동 */
router.get('/pro', function (req, res, next) {
    res.render('index', { title: '교수관리', pageName: 'haksa/professors.ejs' });
});

/*교수목록 데이터 */
router.get('/pro/list.json', async function (req, res) {
    let con;
    try {
        con = await getConnection();
        const sql="select p.*, to_char(hiredate, 'YYYY-MM-DD') fdate, to_char(salary, '99,999,999') fsalary from professors p";
        const result = await con.execute(sql, {}, {outFormat:oracledb.OUT_FORMAT_OBJECT});
        res.send(result.rows);
    } catch (err) {
        console.log('교수 목록 조회 오류:', err);
        res.status(500).json({error: err.message});
    } finally {
        if(con) await con.close();
    }
});

// 교수등록 페이지 이동
router.get('/pro/insert', async function(req, res){
    let con;
    let newcode='';
    try {
        con = await getConnection();
        const sql="select max(pcode)+1 as code from professors";
        const result=await con.execute(sql, {}, {outFormat:oracledb.OUT_FORMAT_OBJECT});
        newcode = result.rows[0]?.code || '';
        console.log('새 교수 코드:', newcode);
    }catch(err){
        console.log('교수 코드 조회 오류:', err);
    }finally{
        if(con) await con.close();
    }
    res.render('index', {title:'교수등록', pageName:'haksa/professors_insert', code:newcode});
});

// 교수등록
router.post('/pro/insert', async function(req, res){
    const pcode=req.body.pcode;
    const pname=req.body.pname;
    const dept=req.body.dept;
    const hiredate=req.body.hiredate;
    const title=req.body.title;
    const salary=req.body.salary;
    console.log('교수 등록:', {pcode, pname, dept, hiredate, title, salary});
    let con;
    try{
        con = await getConnection();
        const sql = `insert into professors(pcode, pname, dept, hiredate, title, salary)` +
                   ` values(:pcode, :pname, :dept, TO_DATE(:hiredate,'YYYY-MM-DD'), :title, :salary)`;
        console.log('SQL:', sql);
        await con.execute(sql, {pcode, pname, dept, hiredate, title, salary}, {autoCommit:true});
        res.sendStatus(200);
    }catch(err){
        console.log('교수 등록 오류:', err);
        res.status(500).json({error: err.message});
    }finally{
        if(con) await con.close();
    }
});

//교수 삭제
router.post('/pro/delete', async function(req, res){
    let con;
    const pcode=req.body.pcode;
    try{
        con = await getConnection();
        const sql=`delete from professors where pcode = :pcode`;
        console.log('교수 삭제:', pcode);
        await con.execute(sql, {pcode}, {autoCommit:true});
        res.sendStatus(200);
    }catch(err){
        res.status(500).json({error: err.message});
        console.log('교수 삭제 오류:', err);
    }finally{
        if(con) await con.close();
    }
});

/* 학생페이지이동 */
router.get('/stu', function (req, res, next) {
    res.render('index', { title: '학생관리', pageName: 'haksa/students.ejs' });
});

/*학생목록 데이터 출력*/
router.get('/stu/list.json', async function (req, res) {
    let con;
    try {
        con = await getConnection();
        const sql="SELECT * FROM students_view";
        const result = await con.execute(sql, {}, {outFormat:oracledb.OUT_FORMAT_OBJECT});
        res.send(result.rows);
    } catch (err) {
        console.log('학생 목록 조회 오류:', err);
        res.status(500).json({error: err.message});
    } finally {
        if(con) await con.close();
    }
});

//학생등록 페이지 이동
router.get('/stu/insert', async function(req, res){
    let con;
    let code = '';
    try{
        con = await getConnection();
        const sql="select max(scode)+1 as code from students";
        const result = await con.execute(sql, {}, {outFormat:oracledb.OUT_FORMAT_OBJECT});
        code = result.rows[0]?.code || '';
        console.log('새 학생 코드:', code);
    }catch(err){
        console.log('학생 코드 조회 오류:', err);
    }finally{
        if(con) await con.close();
    }
    res.render('index', {title: '학생입력', pageName:'haksa/students_insert.ejs', code});
});

// 학생등록
router.post('/stu/insert', async function(req, res){
    const scode=req.body.scode;
    const sname=req.body.sname;
    const dept=req.body.dept;
    const birthday=req.body.birthday;
    const year=req.body.year;
    const pcode=req.body.pcode;
    console.log('학생 등록:', {scode, sname, dept, birthday, year, pcode});
    let con;
    try{
        con = await getConnection();
        const sql = "insert into students(scode, sname, dept, birthday, year, advisor)" +
                   " values(:scode, :sname, :dept, to_date(:birthday, 'YYYY-MM-DD'), :year, :pcode)";
        console.log('SQL:', sql);
        await con.execute(sql, {scode, sname, dept, birthday, year, pcode}, {autoCommit:true});
        res.sendStatus(200);
    }catch(err){
        console.log('학생 등록 오류:', err);
        res.status(500).json({error: err.message});
    }finally{
        if(con) await con.close();
    }
});

//학생 삭제
router.post('/stu/delete', async function(req, res){
    let con;
    const scode=req.body.scode;
    try{
        con = await getConnection();
        const sql="delete from students where scode = :scode";
        console.log('학생 삭제:', scode);
        await con.execute(sql, {scode}, {autoCommit:true});
        res.sendStatus(200);
    }catch(err){
        res.status(500).json({error: err.message});
        console.log('학생 삭제 오류:', err);
    }finally{
        if(con) await con.close();
    }
});

/* 강좌페이지이동 */
router.get('/cou', function (req, res, next) {
    res.render('index', { title: '강좌관리', pageName: 'haksa/courses.ejs' });
});

module.exports = router;