const oracledb = require('oracledb');

let oracleClientReady = false;

//1. Thick 모드 활성화 (선택사항)
try {
    oracledb.initOracleClient({ libDir:'C:\\data\\oracle\\instantclient_19_30' });
    oracleClientReady = true;
    console.log('✅ Oracle 클라이언트 초기화 완료');
}catch(err){
    console.log('⚠️  Oracle 클라이언트 없음 - Mock 모드로 실행합니다:', err.message);
}

async function getConnection(){
    // Oracle 클라이언트가 없으면 Mock 객체 반환
    if (!oracleClientReady) {
        console.log('[MOCK 모드] DB 쿼리 시뮬레이션');
        return {
            execute: async (sql, params = {}, options = {}) => {
                console.log('[MOCK] SQL:', sql, 'Params:', params);
                return { rows: [] };
            },
            close: async () => {}
        };
    }
    
    // 실제 DB 연결
    let connection;
    try{
        connection = await oracledb.getConnection({
            user:'user106',
            password:'pass',
            connectionString:'172.18.7.141'
        });
        console.log('✅ Oracle DB 연결 성공');
        return connection;
    }catch(err){
        console.log('❌ Oracle DB 연결 오류:', err.message);
        // 연결 실패 시에도 Mock 객체 반환 (앱이 계속 실행되도록)
        return {
            execute: async () => ({ rows: [] }),
            close: async () => {}
        };
    }
}  

module.exports = {getConnection};